param(
    [Parameter(Mandatory = $true)]
    [string]$BaseDir
)

$ErrorActionPreference = "Stop"

$GitHubUser   = "fatihhd4006-dd"
$GitHubRepo   = "kurumsal-yonetim-sistemi"
$GitHubBranch = "main"

$BaseDir = $BaseDir.TrimEnd('\', '/')
$HtmlPath = Join-Path $BaseDir "ogrenci_takip_paneli.html"
if (-not (Test-Path $HtmlPath)) {
    exit 0
}

try {
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 -bor [Net.SecurityProtocolType]::Tls11 -bor [Net.SecurityProtocolType]::Tls
} catch {
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
}

function Compare-SemVer {
    param([string]$RemoteVer, [string]$LocalVer)
    $rClean = ($RemoteVer -replace '[^0-9.]', '').Split('.', [System.StringSplitOptions]::RemoveEmptyEntries)
    $lClean = ($LocalVer -replace '[^0-9.]', '').Split('.', [System.StringSplitOptions]::RemoveEmptyEntries)
    $max = [Math]::Max($rClean.Count, $lClean.Count)
    for ($i = 0; $i -lt $max; $i++) {
        $r = 0; $l = 0
        if ($i -lt $rClean.Count) { [void][int]::TryParse($rClean[$i], [ref]$r) }
        if ($i -lt $lClean.Count) { [void][int]::TryParse($lClean[$i], [ref]$l) }
        if ($r -gt $l) { return 1 }
        if ($r -lt $l) { return -1 }
    }
    return 0
}

function Get-HttpUtf8Text {
    param([string]$Url, [int]$TimeoutMs = 4500)
    $req = [System.Net.HttpWebRequest]::Create($Url)
    $req.Method = "GET"
    $req.Timeout = $TimeoutMs
    $req.ReadWriteTimeout = $TimeoutMs
    $req.UserAgent = "OgrenciPaneliUpdater/1.5"
    $req.CachePolicy = New-Object System.Net.Cache.RequestCachePolicy([System.Net.Cache.RequestCacheLevel]::NoCacheNoStore)
    $resp = $req.GetResponse()
    try {
        $stream = $resp.GetResponseStream()
        $reader = New-Object System.IO.StreamReader($stream, [System.Text.Encoding]::UTF8)
        return $reader.ReadToEnd()
    } finally {
        $resp.Close()
    }
}

try {
    $localHtml = [System.IO.File]::ReadAllText($HtmlPath, [System.Text.Encoding]::UTF8)
    $localVer = "0.0.0"
    if ($localHtml -match 'const\s+APP_CURRENT_VERSION\s*=\s*"([^"]+)"') {
        $localVer = $matches[1]
    }

    $nonce = [DateTimeOffset]::UtcNow.ToUnixTimeSeconds()
    $manifestUrl = "https://raw.githubusercontent.com/$GitHubUser/$GitHubRepo/$GitHubBranch/version.json?t=$nonce"
    $manifestText = Get-HttpUtf8Text -Url $manifestUrl -TimeoutMs 4000
    $manifest = $manifestText | ConvertFrom-Json

    $affected = @()
    if ($manifest.affectedModules) {
        $affected = @($manifest.affectedModules | ForEach-Object { [string]$_ })
    }
    if ($affected.Count -gt 0 -and -not ($affected -contains 'ogrenci') -and -not ($affected -contains 'all')) {
        exit 0
    }

    $remoteVer = if ($manifest.ogrenciVersion) { [string]$manifest.ogrenciVersion } elseif ($manifest.version) { [string]$manifest.version } else { "" }
    if (-not $remoteVer) { exit 0 }

    if ((Compare-SemVer -RemoteVer $remoteVer -LocalVer $localVer) -le 0) {
        exit 0
    }

    $dlUrl = if ($manifest.ogrenciDownloadUrl) {
        [string]$manifest.ogrenciDownloadUrl
    } else {
        "https://raw.githubusercontent.com/$GitHubUser/$GitHubRepo/$GitHubBranch/ogrenci_takip_paneli.html"
    }
    $sep = if ($dlUrl.Contains('?')) { '&' } else { '?' }
    $newHtml = Get-HttpUtf8Text -Url "${dlUrl}${sep}t=$nonce" -TimeoutMs 10000

    if (-not $newHtml -or -not $newHtml.Contains('<html') -or -not $newHtml.Contains('checkSystemUpdates')) {
        exit 0
    }

    $tmpPath = "$HtmlPath.tmp"
    $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
    [System.IO.File]::WriteAllText($tmpPath, $newHtml, $utf8NoBom)
    Move-Item -Path $tmpPath -Destination $HtmlPath -Force
    Write-Host "[Ogrenci Takip Paneli] v$localVer -> v$remoteVer guncellendi (Veri_Profili korundu)."
} catch {
    # Cevrimdisi veya ag hatasinda sessizce yerel surumle devam et
    exit 0
}
