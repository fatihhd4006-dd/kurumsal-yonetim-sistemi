@echo off
chcp 65001 >nul
title Ogrenci Takip ve Yonetim Sistemi - Baslatici
cd /d "%~dp0"

set "BASE_DIR=%~dp0"
if "%BASE_DIR:~-1%"=="\" set "BASE_DIR=%BASE_DIR:~0,-1%"

set "HTML_PATH=%~dp0ogrenci_takip_paneli.html"
set "DATA_PROFILE=%~dp0Veri_Profili"
set "UPDATER_PS1=%~dp0Ogrenci_Guncelle.ps1"

if not exist "%DATA_PROFILE%" (
    mkdir "%DATA_PROFILE%" >nul 2>&1
)

:: 1. Acilista GitHub uzerinden yalnizca Ogrenci modulunu ilgilendiren guncelleme varsa indir (Veri_Profili korunur)
if exist "%UPDATER_PS1%" (
    echo [Ogrenci Takip Paneli] Guncellemeler denetleniyor...
    powershell -NoProfile -ExecutionPolicy Bypass -File "%UPDATER_PS1%" -BaseDir "%BASE_DIR%"
)

:: 2. Turkce karakter ve bosluk iceren yolu gecerli file:/// URI bicimine cevir
set "OGR_HTML=%HTML_PATH%"
set "HTML_URI="
for /f "delims=" %%U in ('powershell -NoProfile -Command "[System.Uri]::new($env:OGR_HTML).AbsoluteUri"') do set "HTML_URI=%%U"
if not defined HTML_URI set "HTML_URI=%HTML_PATH%"

:: 3. Microsoft Edge veya Google Chrome ile izole Veri_Profili icinde ac
set "TARGET_BROWSER="
if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" (
    set "TARGET_BROWSER=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
) else if exist "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" (
    set "TARGET_BROWSER=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"
) else if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" (
    set "TARGET_BROWSER=%ProgramFiles%\Google\Chrome\Application\chrome.exe"
) else if exist "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" (
    set "TARGET_BROWSER=%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"
) else if exist "%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe" (
    set "TARGET_BROWSER=%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe"
)

if defined TARGET_BROWSER (
    start "" "%TARGET_BROWSER%" --app="%HTML_URI%" --user-data-dir="%DATA_PROFILE%" --no-first-run --no-default-browser-check
    exit
)

start "" "%HTML_PATH%"
exit
